// ============================================================
//  TALLER 3 – GRUPO 2
//  Universidad de los Andes — IELE 3338 L — 2026-10
//
//  calibracion_servos.ino
//
//  Script de calibración de ángulos de los servos.
//  Mueve cada servo por todos sus ángulos en pasos de 30°
//  con una pausa de 5 segundos entre posiciones.
//  Anotar qué posición física corresponde a cada ángulo.
//
//  RESULTADO DE CALIBRACIÓN (Grupo 2):
//    Servo 1 (Pin 2 — altura):
//      0°   → Paletas al nivel del piso (posición de recogida)
//      180° → Brazo arriba (posición de transporte)
//
//    Servo 2 (Pin 3 — extensión):
//      90°  → Posición central (fija durante operación)
// ============================================================

#include <Servo.h>

Servo servo_pin2;   // altura del brazo
Servo servo_pin3;   // extensión del brazo

void mover(int a2, int a3, String desc) {
  servo_pin2.write(a2);
  servo_pin3.write(a3);
  Serial.print(">>> ");
  Serial.println(desc);
  Serial.print("    PIN2="); Serial.print(a2);
  Serial.print("  PIN3=");   Serial.println(a3);
  delay(5000);  // 5 segundos para observar y anotar
}

void setup() {
  Serial.begin(115200);

  servo_pin2.attach(2, 300, 2700);
  servo_pin3.attach(3, 400, 2600);

  Serial.println("========================================");
  Serial.println("  CALIBRACION DE SERVOS — Taller 3");
  Serial.println("  Cada posicion dura 5 segundos");
  Serial.println("  Anota que posicion fisica corresponde");
  Serial.println("========================================");
  delay(2000);

  // ── Barrido de PIN2 (altura) con PIN3 fijo en 90 ───────
  Serial.println("\n--- BARRIDO PIN2 (ALTURA) ---");
  mover(0,   90, "PIN2=0   (mas abajo posible)");
  mover(30,  90, "PIN2=30");
  mover(60,  90, "PIN2=60");
  mover(90,  90, "PIN2=90  (centro)");
  mover(120, 90, "PIN2=120");
  mover(150, 90, "PIN2=150");
  mover(180, 90, "PIN2=180 (mas arriba posible)");

  delay(3000);
  Serial.println("\n--- BARRIDO PIN3 (EXTENSION) ---");

  // ── Barrido de PIN3 (extensión) con PIN2 fijo en 0 ─────
  mover(0, 0,   "PIN2=0 (piso) + PIN3=0");
  mover(0, 30,  "PIN2=0 (piso) + PIN3=30");
  mover(0, 60,  "PIN2=0 (piso) + PIN3=60");
  mover(0, 90,  "PIN2=0 (piso) + PIN3=90  (centro)");
  mover(0, 120, "PIN2=0 (piso) + PIN3=120");
  mover(0, 150, "PIN2=0 (piso) + PIN3=150");
  mover(0, 180, "PIN2=0 (piso) + PIN3=180");

  // ── Posiciones finales calibradas ───────────────────────
  delay(3000);
  Serial.println("\n--- POSICIONES CALIBRADAS FINALES ---");
  mover(180, 90, "HOME — brazo arriba, transporte");
  mover(0,   90, "RECOGER — paletas al piso");
  mover(180, 90, "HOME — vuelve arriba");

  Serial.println("\n========================================");
  Serial.println("  CALIBRACION COMPLETA");
  Serial.println("  Edita taller3_main.ino con los angulos");
  Serial.println("  correctos para tu robot.");
  Serial.println("========================================");
}

void loop() {
  // Mantener última posición (HOME)
  servo_pin2.write(180);
  servo_pin3.write(90);
}
