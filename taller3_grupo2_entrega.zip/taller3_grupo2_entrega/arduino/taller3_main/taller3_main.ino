// ============================================================
//  TALLER 3 – GRUPO 2
//  Universidad de los Andes — IELE 3338 L — 2026-10
//
//  Arduino Mega 2560
//  Control de motores DC (L298N), brazo robótico (2 servos)
//  y sensor ultrasónico HC-SR04.
//
//  Comunicación serial con Raspberry Pi 5 a 115200 baudios.
//  Recibe comandos de texto y responde con mensajes de estado.
// ============================================================

#include <Servo.h>

// ── Pines motores (L298N) ────────────────────────────────────
#define PIN_IZQ_IN1   8
#define PIN_IZQ_IN2   9
#define PIN_IZQ_EN    10    // PWM — motor izquierdo
#define PIN_DER_IN1   11
#define PIN_DER_IN2   12
#define PIN_DER_EN    13    // PWM — motor derecho

// ── Pines servos del brazo ───────────────────────────────────
#define PIN_SERVO1    2     // Servo 1: altura (sube/baja el brazo)
#define PIN_SERVO2    3     // Servo 2: extensión (adelante/atrás)

// ── Pines sensor ultrasónico HC-SR04 ─────────────────────────
#define PIN_TRIG      30
#define PIN_ECHO      31

// ── Ángulos de servo calibrados físicamente ──────────────────
//    AJUSTAR según el robot real si es necesario
const int ALTURA_HOME      = 180;  // Brazo arriba — posición de transporte
const int ALTURA_PISO      = 0;    // Paletas al piso — posición de recogida
const int EXTENSION_POS    = 90;   // Extensión fija en posición central

// ── Velocidades de motores (0-255 PWM) ───────────────────────
const int VEL_NORMAL = 200;
const int VEL_LENTO  = 140;
const int VEL_GIRO   = 170;

// ── Objetos de servo ─────────────────────────────────────────
Servo servo1;   // Pin 2 — altura del brazo
Servo servo2;   // Pin 3 — extensión del brazo

// ── Estado global ────────────────────────────────────────────
bool brazo_en_uso = false;

// ============================================================
//  SETUP
// ============================================================
void setup() {
  Serial.begin(115200);

  // Configurar pines de motores como salida
  pinMode(PIN_IZQ_IN1, OUTPUT);
  pinMode(PIN_IZQ_IN2, OUTPUT);
  pinMode(PIN_IZQ_EN,  OUTPUT);
  pinMode(PIN_DER_IN1, OUTPUT);
  pinMode(PIN_DER_IN2, OUTPUT);
  pinMode(PIN_DER_EN,  OUTPUT);

  // Configurar pines de ultrasonido
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);

  // Inicializar servos con rango extendido para mayor recorrido
  servo1.attach(PIN_SERVO1, 300, 2700);
  servo2.attach(PIN_SERVO2, 400, 2600);

  // Ir a posición HOME al iniciar
  posicion_home();

  Serial.println("ARDUINO_LISTO");
}

// ============================================================
//  LOOP — Lectura de comandos por serial
// ============================================================
void loop() {
  if (Serial.available() > 0) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();
    if (cmd.length() > 0) {
      procesar_comando(cmd);
    }
  }
}

// ============================================================
//  PROCESADOR DE COMANDOS
// ============================================================
void procesar_comando(String cmd) {

  // ── Comandos de movimiento ──────────────────────────────
  if      (cmd == "FORWARD")      { mover_adelante(VEL_NORMAL); }
  else if (cmd == "FORWARD_SLOW") { mover_adelante(VEL_LENTO);  }
  else if (cmd == "BACKWARD")     { mover_atras(VEL_NORMAL);    }
  else if (cmd == "LEFT")         { girar_izq(VEL_GIRO);        }
  else if (cmd == "RIGHT")        { girar_der(VEL_GIRO);        }
  else if (cmd == "STOP")         { detener();                  }

  // ── Comandos del brazo completo ─────────────────────────
  else if (cmd == "ARM_HOME")  { posicion_home();     }
  else if (cmd == "ARM_PICK")  { secuencia_recoger(); }
  else if (cmd == "AUTO_PICK") { secuencia_recoger(); }

  // ── Control individual servo 1 (altura) ─────────────────
  else if (cmd == "ARM_UP") {
    servo1.write(ALTURA_HOME);
    delay(800);
    Serial.println("OK");
  }
  else if (cmd == "ARM_DOWN") {
    servo1.write(ALTURA_PISO);
    delay(800);
    Serial.println("OK");
  }
  else if (cmd == "ARM_MID") {
    servo1.write(90);
    delay(600);
    Serial.println("OK");
  }

  // ── Control individual servo 2 (extensión) ──────────────
  else if (cmd == "ARM_EXTEND") {
    servo2.write(EXTENSION_POS);
    delay(500);
    Serial.println("OK");
  }
  else if (cmd == "ARM_RETRACT") {
    servo2.write(EXTENSION_POS);
    delay(500);
    Serial.println("OK");
  }

  // ── Ultrasonido bajo demanda ─────────────────────────────
  else if (cmd == "DIST?") {
    float d = leer_distancia_cm();
    Serial.print("DIST:");
    Serial.println(d, 2);
  }

  // ── Comando desconocido ──────────────────────────────────
  else {
    Serial.print("CMD_DESCONOCIDO:");
    Serial.println(cmd);
  }
}

// ============================================================
//  FUNCIONES DE MOVIMIENTO DE MOTORES
// ============================================================

void mover_adelante(int vel) {
  analogWrite(PIN_IZQ_EN, vel);
  analogWrite(PIN_DER_EN, vel);
  digitalWrite(PIN_IZQ_IN1, HIGH); digitalWrite(PIN_IZQ_IN2, LOW);
  digitalWrite(PIN_DER_IN1, LOW);  digitalWrite(PIN_DER_IN2, HIGH);
}

void mover_atras(int vel) {
  analogWrite(PIN_IZQ_EN, vel);
  analogWrite(PIN_DER_EN, vel);
  digitalWrite(PIN_IZQ_IN1, LOW);  digitalWrite(PIN_IZQ_IN2, HIGH);
  digitalWrite(PIN_DER_IN1, HIGH); digitalWrite(PIN_DER_IN2, LOW);
}

void girar_izq(int vel) {
  analogWrite(PIN_IZQ_EN, vel);
  analogWrite(PIN_DER_EN, vel);
  digitalWrite(PIN_IZQ_IN1, LOW);  digitalWrite(PIN_IZQ_IN2, HIGH);
  digitalWrite(PIN_DER_IN1, LOW);  digitalWrite(PIN_DER_IN2, HIGH);
}

void girar_der(int vel) {
  analogWrite(PIN_IZQ_EN, vel);
  analogWrite(PIN_DER_EN, vel);
  digitalWrite(PIN_IZQ_IN1, HIGH); digitalWrite(PIN_IZQ_IN2, LOW);
  digitalWrite(PIN_DER_IN1, HIGH); digitalWrite(PIN_DER_IN2, LOW);
}

void detener() {
  analogWrite(PIN_IZQ_EN, 0);
  analogWrite(PIN_DER_EN, 0);
  digitalWrite(PIN_IZQ_IN1, LOW); digitalWrite(PIN_IZQ_IN2, LOW);
  digitalWrite(PIN_DER_IN1, LOW); digitalWrite(PIN_DER_IN2, LOW);
}

// ============================================================
//  FUNCIONES DE ULTRASONIDO HC-SR04
// ============================================================

float leer_distancia_cm() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);

  long duracion = pulseIn(PIN_ECHO, HIGH, 25000);
  if (duracion == 0) return 999.0;   // Sin eco = objeto muy lejos

  return (duracion * 0.0343f) / 2.0f;
}

// ============================================================
//  POSICIÓN HOME — brazo arriba para transporte seguro
// ============================================================

void posicion_home() {
  servo1.write(ALTURA_HOME);    // Sube el brazo a 180°
  servo2.write(EXTENSION_POS); // Extensión al centro
  delay(800);
  Serial.println("HOME_OK");
}

// ============================================================
//  SECUENCIA DE RECOGIDA (tipo montacarga)
//
//  El cubo tiene un hueco en la base. Las paletas entran
//  por debajo y levantan el cubo al subir el brazo.
//
//  Pasos:
//    1. Sube a HOME por seguridad (evitar colisiones)
//    2. Baja las paletas al nivel del piso (0°)
//    3. Espera 5 segundos (paletas entran bajo el cubo)
//    4. Sube el brazo a HOME (180°) levantando el cubo
// ============================================================

void secuencia_recoger() {
  if (brazo_en_uso) {
    Serial.println("BRAZO_OCUPADO");
    return;
  }
  brazo_en_uso = true;
  Serial.println("PICK_INICIO");

  // Paso 1 — Sube a HOME primero por seguridad
  servo1.write(ALTURA_HOME);
  servo2.write(EXTENSION_POS);
  delay(1000);

  // Paso 2 — Baja las paletas al piso
  servo1.write(ALTURA_PISO);
  delay(1500);

  // Paso 3 — Esperar en posición de recogida
  Serial.println("ESPERANDO_EN_PISO");
  delay(5000);

  // Paso 4 — Levantar el brazo con el cubo
  servo1.write(ALTURA_HOME);
  delay(1500);

  brazo_en_uso = false;
  Serial.println("PICK_OK");
}
