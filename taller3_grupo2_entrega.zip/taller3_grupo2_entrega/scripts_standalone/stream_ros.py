#!/usr/bin/env python3
"""
stream_ros.py — Taller 3, Grupo 2
Universidad de los Andes — IELE 3338 L — 2026-10

Servidor HTTP que transmite la imagen procesada del vision_node
con bounding boxes de detección.

Lee del tópico ROS2: /taller3/imagen_procesada
Puerto HTTP: 8082

IMPORTANTE: Este script corre AL MISMO TIEMPO que el launch.
            NO usa la cámara directamente.

Acceso desde PC: http://IP_RASPBERRY:8082
"""

import threading
import time
import socket
from http.server import BaseHTTPRequestHandler, HTTPServer
import cv2

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

PUERTO     = 8082
frame_jpg  = None
lock_frame = threading.Lock()


class StreamNode(Node):
    def __init__(self):
        super().__init__('stream_node')
        self.bridge = CvBridge()
        self.sub = self.create_subscription(
            Image,
            '/taller3/imagen_procesada',
            self._cb_img,
            10)
        self.get_logger().info('StreamNode iniciado.')

    def _cb_img(self, msg):
        global frame_jpg
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            ret, jpg = cv2.imencode(
                '.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
            if ret:
                with lock_frame:
                    frame_jpg = jpg.tobytes()
        except Exception as e:
            self.get_logger().error(f'Error: {e}')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        if   self.path == '/':       self._pagina()
        elif self.path == '/stream': self._stream()
        else:
            self.send_response(404); self.end_headers()

    def _pagina(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.end_headers()
        html = (
            "<!DOCTYPE html><html><head><meta charset='utf-8'>"
            "<title>Taller3 Vision</title>"
            "<style>body{margin:0;background:#0d0f14;display:flex;"
            "flex-direction:column;align-items:center;"
            "justify-content:center;min-height:100vh;"
            "font-family:monospace;color:#e2e8f8;}"
            "h1{color:#4f8ef7;font-size:18px;margin-bottom:16px;}"
            ".box{border:2px solid #252a38;border-radius:10px;overflow:hidden;}"
            "img{display:block;width:640px;height:480px;}"
            ".info{margin-top:12px;color:#6b7694;font-size:12px;}"
            "</style></head><body>"
            "<h1>Taller 3 Grupo 2 — Detección en Tiempo Real</h1>"
            "<div class='box'><img src='/stream'/></div>"
            "<p class='info'>Bounding box + color + estado</p>"
            "</body></html>"
        )
        self.wfile.write(html.encode('utf-8'))

    def _stream(self):
        self.send_response(200)
        self.send_header('Content-type',
                         'multipart/x-mixed-replace; boundary=frame')
        self.end_headers()
        try:
            while True:
                with lock_frame:
                    jpg = frame_jpg
                if jpg:
                    self.wfile.write(b'--frame\r\n')
                    self.wfile.write(b'Content-Type: image/jpeg\r\n\r\n')
                    self.wfile.write(jpg)
                    self.wfile.write(b'\r\n')
                time.sleep(0.033)
        except (BrokenPipeError, ConnectionResetError):
            pass


def iniciar_servidor():
    srv = HTTPServer(('0.0.0.0', PUERTO), Handler)
    print(f'[HTTP] Servidor activo en puerto {PUERTO}')
    srv.serve_forever()


def obtener_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return 'IP_RASPBERRY'


def main():
    ip = obtener_ip()
    print('=' * 50)
    print(f'  stream_ros.py — Taller 3 Grupo 2')
    print(f'  Abre en tu PC: http://{ip}:{PUERTO}')
    print('  Ctrl+C para detener')
    print('=' * 50)

    rclpy.init()
    node = StreamNode()

    hilo = threading.Thread(target=iniciar_servidor, daemon=True)
    hilo.start()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
