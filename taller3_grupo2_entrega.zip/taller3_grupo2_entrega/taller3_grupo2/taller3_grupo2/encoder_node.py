#!/usr/bin/env python3
"""
encoder_node.py — Taller 3, Grupo 2
Universidad de los Andes — IELE 3338 L — 2026-10

Lee los encoders de las ruedas mediante GPIO de la Raspberry Pi 5.
Publica los ticks acumulados en /wheel_ticks.

Pines GPIO:
  Motor Izquierdo: GPIO 17 (canal A)
  Motor Derecho:   GPIO 27 (canal A)
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32MultiArray

# ── Configuración de pines GPIO ───────────────────────────────
ENC_IZQ_A = 17
ENC_DER_A = 27

# ── Parámetros del encoder ────────────────────────────────────
PULSOS_POR_VUELTA = 330


class EncoderNode(Node):
    def __init__(self):
        super().__init__('encoder_node')

        # Publicador de ticks de ruedas
        self.pub = self.create_publisher(
            Int32MultiArray, '/wheel_ticks', 10)

        self.ticks_izq = 0
        self.ticks_der = 0

        # Intentar inicializar GPIO
        try:
            from gpiozero import RotaryEncoder
            self.enc_izq = RotaryEncoder(ENC_IZQ_A, ENC_IZQ_A)
            self.enc_der = RotaryEncoder(ENC_DER_A, ENC_DER_A)
            self.simulacion = False
            self.get_logger().info(
                f'EncoderNode iniciado — Pines: Izq={ENC_IZQ_A}, Der={ENC_DER_A}')
        except Exception:
            self.simulacion = True
            self.get_logger().warn(
                '[SIMULACION] GPIO no disponible. Ticks siempre en 0.')

        # Timer de publicación a ~100 Hz
        self.create_timer(0.01, self._publicar)

    def _publicar(self):
        """Lee los ticks de los encoders y los publica."""
        if not self.simulacion:
            self.ticks_izq = int(self.enc_izq.steps)
            self.ticks_der = int(self.enc_der.steps)

        msg = Int32MultiArray()
        msg.data = [self.ticks_izq, self.ticks_der]
        self.pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = EncoderNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
