#!/usr/bin/env python3
"""
odometry_node.py — Taller 3, Grupo 2
Universidad de los Andes — IELE 3338 L — 2026-10

Calcula la odometría del robot diferencial a partir de los ticks
de los encoders de rueda. Implementa la cinemática diferencial:

    v   = (v_der + v_izq) / 2
    w   = (v_der - v_izq) / L
    x  += v * cos(theta) * dt
    y  += v * sin(theta) * dt
    θ  += w * dt

Publica:
  /odom       (nav_msgs/Odometry)
  /robot_pose (std_msgs/Float32MultiArray)  → [x, y, theta]
"""

import math
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32MultiArray, Float32MultiArray
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
import tf2_ros

# ── Parámetros físicos del robot — MEDIR Y CALIBRAR ──────────
RADIO_RUEDA       = 0.033   # metros — radio de la rueda
ANCHO_VIA         = 0.15    # metros — distancia entre ruedas
PULSOS_POR_VUELTA = 330     # pulsos por vuelta completa del encoder
DIST_POR_PULSO    = (2 * math.pi * RADIO_RUEDA) / PULSOS_POR_VUELTA


class OdometryNode(Node):
    def __init__(self):
        super().__init__('odometry_node')

        # Publicadores
        self.pub_odom  = self.create_publisher(Odometry,           '/odom',        10)
        self.pub_pose  = self.create_publisher(Float32MultiArray,   '/robot_pose',  10)

        # Suscriptor
        self.sub_ticks = self.create_subscription(
            Int32MultiArray, '/wheel_ticks', self._cb_ticks, 10)

        # Broadcaster de transformadas TF
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)

        # Estado del robot
        self.x     = 0.0
        self.y     = 0.0
        self.theta = 0.0

        # Ticks anteriores
        self.ticks_izq_prev = None
        self.ticks_der_prev = None

        self.get_logger().info(
            f'OdometryNode iniciado — R={RADIO_RUEDA}m, '
            f'L={ANCHO_VIA}m, PPV={PULSOS_POR_VUELTA}, '
            f'dist/pulso={DIST_POR_PULSO*1000:.3f}mm')

    def _cb_ticks(self, msg: Int32MultiArray):
        """Calcula la odometría a partir del delta de ticks."""
        ticks_izq = msg.data[0]
        ticks_der = msg.data[1]

        # Primera lectura — solo guardar referencia
        if self.ticks_izq_prev is None:
            self.ticks_izq_prev = ticks_izq
            self.ticks_der_prev = ticks_der
            return

        # Delta de ticks
        d_izq = (ticks_izq - self.ticks_izq_prev) * DIST_POR_PULSO
        d_der = (ticks_der - self.ticks_der_prev) * DIST_POR_PULSO

        self.ticks_izq_prev = ticks_izq
        self.ticks_der_prev = ticks_der

        # Cinemática diferencial
        d_centro = (d_der + d_izq) / 2.0
        d_theta  = (d_der - d_izq) / ANCHO_VIA

        self.theta += d_theta
        self.x     += d_centro * math.cos(self.theta)
        self.y     += d_centro * math.sin(self.theta)

        # Normalizar theta en [-pi, pi]
        self.theta = math.atan2(
            math.sin(self.theta), math.cos(self.theta))

        self._publicar()

    def _publicar(self):
        """Publica la pose calculada en /odom y /robot_pose."""
        ahora = self.get_clock().now().to_msg()

        # ── Odometry message ─────────────────────────────────
        odom = Odometry()
        odom.header.stamp    = ahora
        odom.header.frame_id = 'odom'
        odom.child_frame_id  = 'base_link'

        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.position.z = 0.0

        # Quaternion desde yaw
        odom.pose.pose.orientation.z = math.sin(self.theta / 2.0)
        odom.pose.pose.orientation.w = math.cos(self.theta / 2.0)

        self.pub_odom.publish(odom)

        # ── Float array [x, y, theta] ────────────────────────
        pose_msg = Float32MultiArray()
        pose_msg.data = [float(self.x), float(self.y), float(self.theta)]
        self.pub_pose.publish(pose_msg)

        # ── TF transform ─────────────────────────────────────
        t = TransformStamped()
        t.header.stamp            = ahora
        t.header.frame_id         = 'odom'
        t.child_frame_id          = 'base_link'
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0
        t.transform.rotation.z    = math.sin(self.theta / 2.0)
        t.transform.rotation.w    = math.cos(self.theta / 2.0)
        self.tf_broadcaster.sendTransform(t)


def main(args=None):
    rclpy.init(args=args)
    node = OdometryNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
