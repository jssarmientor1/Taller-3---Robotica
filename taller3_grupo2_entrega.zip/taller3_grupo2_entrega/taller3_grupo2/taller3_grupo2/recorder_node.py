#!/usr/bin/env python3
"""
recorder_node.py — Taller 3, Grupo 2
Universidad de los Andes — IELE 3338 L — 2026-10

Graba los comandos de velocidad (/cmd_vel) en archivos de texto
para su posterior reproducción por player_node.

Formato del archivo guardado:
  linear_x angular_z timestamp
  (una línea por cada mensaje recibido)

Control:
  /recording_ctrl  "start:nombre_recorrido"  → inicia grabación
  /recording_ctrl  "stop"                    → detiene grabación
"""

import os
import time
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String

# Carpeta donde se guardan los recorridos
RUTA_RECORRIDOS = os.path.expanduser(
    '~/ros2_ws/src/taller3_grupo2/recorridos')


class RecorderNode(Node):
    def __init__(self):
        super().__init__('recorder_node')

        self.sub_vel  = self.create_subscription(
            Twist,  '/cmd_vel',         self._cb_vel,   10)
        self.sub_ctrl = self.create_subscription(
            String, '/recording_ctrl',  self._cb_ctrl,  10)

        self.grabando   = False
        self.archivo    = None
        self.ultimo_cmd = None
        self.t_inicio   = 0.0

        # Asegurar que la carpeta de recorridos existe
        os.makedirs(RUTA_RECORRIDOS, exist_ok=True)

        self.get_logger().info('RecorderNode iniciado.')

    def _cb_ctrl(self, msg: String):
        """Controla inicio/fin de grabación."""
        data = msg.data.strip()

        if data.startswith('start:'):
            nombre = data.split(':', 1)[1].strip()
            self._iniciar(nombre)

        elif data == 'stop':
            self._detener()

    def _iniciar(self, nombre: str):
        """Abre el archivo y activa la grabación."""
        if self.grabando:
            self._detener()

        ruta = os.path.join(RUTA_RECORRIDOS, f'{nombre}.txt')
        self.archivo  = open(ruta, 'w')
        self.grabando = True
        self.t_inicio = time.time()
        self.get_logger().info(f'[REC] Grabando: {ruta}')

    def _detener(self):
        """Cierra el archivo y detiene la grabación."""
        if self.archivo:
            self.archivo.close()
            self.archivo = None
        self.grabando = False
        self.get_logger().info('[REC] Grabación detenida.')

    def _cb_vel(self, msg: Twist):
        """Guarda cada comando de velocidad en el archivo."""
        if not self.grabando or self.archivo is None:
            return

        t = time.time() - self.t_inicio
        lx = msg.linear.x
        az = msg.angular.z

        # Evitar guardar duplicados exactos
        cmd_actual = (lx, az)
        if cmd_actual == self.ultimo_cmd:
            return
        self.ultimo_cmd = cmd_actual

        self.archivo.write(f'{lx:.4f} {az:.4f} {t:.4f}\n')
        self.archivo.flush()

    def destroy_node(self):
        if self.grabando:
            self._detener()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = RecorderNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
