#!/usr/bin/env python3
"""
serial_bridge_node.py — Taller 3, Grupo 2
Universidad de los Andes — IELE 3338 L — 2026-10

Puente bidireccional entre ROS2 y el Arduino Mega por USB serial.

Funciones:
  - Traduce /cmd_vel (Twist) → comandos de texto al Arduino
  - Reenvía /taller3/comando_robot → Arduino directamente
  - Lee respuestas del Arduino (incluyendo lecturas del ultrasonido)
  - Publica /taller3/ultrasonido (Float32) con la distancia en cm
  - Watchdog: envía STOP si no llega /cmd_vel en 0.5 segundos
  - Reconexión automática si se desconecta el Arduino
"""

import serial
import time
import threading
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import String, Float32

# ── Configuración serial ──────────────────────────────────────
PUERTO_SERIAL  = '/dev/ttyACM0'
BAUDRATE       = 115200

# ── Parámetros ────────────────────────────────────────────────
WATCHDOG_SEG   = 0.5    # segundos sin /cmd_vel antes de STOP
UMBRAL_LIN     = 0.02   # velocidad lineal mínima
UMBRAL_ANG     = 0.05   # velocidad angular mínima
INTERVALO_DIST = 0.5    # cada cuánto pedir distancia al ultrasonido (s)


class SerialBridgeNode(Node):
    def __init__(self):
        super().__init__('serial_bridge_node')

        # Suscriptores
        self.sub_vel = self.create_subscription(
            Twist,  '/cmd_vel',               self._cb_cmd_vel, 10)
        self.sub_arm = self.create_subscription(
            String, '/taller3/comando_robot',  self._cb_arm_cmd, 10)

        # Publicador de distancia ultrasónica
        self.pub_dist = self.create_publisher(
            Float32, '/taller3/ultrasonido', 10)

        # Estado interno
        self.ultimo_cmd_t = time.time()
        self.ultimo_cmd   = 'STOP'
        self.arduino      = None
        self.serial_ok    = False

        # Conectar al Arduino
        self._conectar_serial()

        # Timers
        self.create_timer(0.1,          self._watchdog)
        self.create_timer(INTERVALO_DIST, self._pedir_distancia)

        # Hilo lector de respuestas del Arduino
        if self.serial_ok:
            threading.Thread(
                target=self._leer_serial, daemon=True).start()

        self.get_logger().info('SerialBridgeNode iniciado.')

    # ── Conexión serial ───────────────────────────────────────
    def _conectar_serial(self):
        try:
            self.arduino   = serial.Serial(
                PUERTO_SERIAL, BAUDRATE, timeout=1)
            time.sleep(2)
            self.serial_ok = True
            resp = self.arduino.readline().decode(errors='ignore').strip()
            self.get_logger().info(
                f'[SERIAL] Conectado {PUERTO_SERIAL} — Arduino: {resp}')
        except Exception as e:
            self.serial_ok = False
            self.get_logger().warn(
                f'[SERIAL] Sin conexión ({e}). Modo simulación.')

    # ── Lector de respuestas del Arduino (hilo separado) ──────
    def _leer_serial(self):
        while rclpy.ok():
            try:
                if self.arduino and self.arduino.in_waiting > 0:
                    linea = self.arduino.readline().decode(
                        errors='ignore').strip()
                    if linea:
                        self.get_logger().info(f'[Arduino→] {linea}')
                        # Parsear lectura de distancia DIST:XX.XX
                        if linea.startswith('DIST:'):
                            try:
                                dist     = float(linea.split(':')[1])
                                msg      = Float32()
                                msg.data = dist
                                self.pub_dist.publish(msg)
                            except Exception:
                                pass
                time.sleep(0.05)
            except Exception as e:
                self.get_logger().error(f'[SERIAL] Error lectura: {e}')
                self.serial_ok = False
                time.sleep(2)
                self._conectar_serial()
                break

    # ── Solicitar distancia al ultrasonido ────────────────────
    def _pedir_distancia(self):
        if self.serial_ok and self.arduino:
            try:
                self.arduino.write(b'DIST?\n')
            except Exception:
                pass

    # ── Enviar comando al Arduino ─────────────────────────────
    def _enviar(self, cmd: str):
        # Evitar reenviar el mismo comando repetidamente
        # (excepto comandos de brazo que siempre deben enviarse)
        if cmd == self.ultimo_cmd and cmd not in (
                'ARM_PICK', 'AUTO_PICK', 'ARM_HOME', 'DIST?'):
            return
        self.ultimo_cmd = cmd

        if self.serial_ok and self.arduino:
            try:
                self.arduino.write((cmd + '\n').encode())
                self.get_logger().info(f'[→Arduino] {cmd}')
            except Exception as e:
                self.get_logger().error(f'[SERIAL] Error escritura: {e}')
                self.serial_ok = False
                self.arduino   = None
                self.get_logger().warn('[SERIAL] Reconectando...')
                time.sleep(2)
                self._conectar_serial()
        else:
            self.get_logger().info(f'[SIM] {cmd}')

    # ── Callback /cmd_vel ─────────────────────────────────────
    def _cb_cmd_vel(self, msg: Twist):
        self.ultimo_cmd_t = time.time()
        lx = msg.linear.x
        az = msg.angular.z

        if   lx >  UMBRAL_LIN: self._enviar('FORWARD')
        elif lx < -UMBRAL_LIN: self._enviar('BACKWARD')
        elif az >  UMBRAL_ANG: self._enviar('LEFT')
        elif az < -UMBRAL_ANG: self._enviar('RIGHT')
        else:                  self._enviar('STOP')

    # ── Callback /taller3/comando_robot ──────────────────────
    def _cb_arm_cmd(self, msg: String):
        self._enviar(msg.data)

    # ── Watchdog: STOP si no llega cmd_vel ───────────────────
    def _watchdog(self):
        if (time.time() - self.ultimo_cmd_t) > WATCHDOG_SEG:
            self._enviar('STOP')

    def destroy_node(self):
        self._enviar('STOP')
        if self.serial_ok and self.arduino:
            try:
                self.arduino.close()
            except Exception:
                pass
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = SerialBridgeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
