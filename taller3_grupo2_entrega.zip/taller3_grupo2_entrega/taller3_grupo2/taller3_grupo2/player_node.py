#!/usr/bin/env python3
"""
player_node.py — Taller 3, Grupo 2
Universidad de los Andes — IELE 3338 L — 2026-10

Reproduce recorridos grabados por recorder_node publicando
los comandos originales en /cmd_vel respetando los tiempos.

Servicio:
  /play_route (taller3_interfaces/srv/PlayRoute)
    Request:  filename (string) — nombre del archivo sin .txt
    Response: success (bool), message (string)
"""

import os
import time
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from taller3_interfaces.srv import PlayRoute

RUTA_RECORRIDOS = os.path.expanduser(
    '~/ros2_ws/src/taller3_grupo2/recorridos')


class PlayerNode(Node):
    def __init__(self):
        super().__init__('player_node')

        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)

        # Servicio de reproducción
        self.srv = self.create_service(
            PlayRoute, '/play_route', self._cb_play)

        self.get_logger().info(
            'PlayerNode iniciado. Servicio /play_route disponible.')

    def _cb_play(self, request, response):
        """Callback del servicio — reproduce el recorrido solicitado."""
        nombre = request.filename.strip()
        ruta   = os.path.join(RUTA_RECORRIDOS, f'{nombre}.txt')

        if not os.path.exists(ruta):
            # Intentar sin extensión por si ya la incluye
            ruta_alt = os.path.join(RUTA_RECORRIDOS, nombre)
            if os.path.exists(ruta_alt):
                ruta = ruta_alt
            else:
                response.success = False
                response.message = f'Archivo no encontrado: {ruta}'
                self.get_logger().error(response.message)
                return response

        self.get_logger().info(f'[PLAY] Reproduciendo: {ruta}')

        try:
            with open(ruta, 'r') as f:
                lineas = f.readlines()

            t_anterior = 0.0
            for linea in lineas:
                linea = linea.strip()
                if not linea:
                    continue

                partes = linea.split()
                if len(partes) < 3:
                    continue

                lx = float(partes[0])
                az = float(partes[1])
                t  = float(partes[2])

                # Respetar el tiempo original entre comandos
                dt = t - t_anterior
                if dt > 0:
                    time.sleep(dt)
                t_anterior = t

                msg           = Twist()
                msg.linear.x  = lx
                msg.angular.z = az
                self.pub.publish(msg)

            # Parar el robot al terminar
            self.pub.publish(Twist())
            response.success = True
            response.message = f'Recorrido {nombre} completado.'
            self.get_logger().info(response.message)

        except Exception as e:
            response.success = False
            response.message = f'Error reproduciendo {nombre}: {e}'
            self.get_logger().error(response.message)

        return response


def main(args=None):
    rclpy.init(args=args)
    node = PlayerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
