#!/usr/bin/env python3
"""
vision_node.py — Taller 3, Grupo 2
Universidad de los Andes — IELE 3338 L — 2026-10

Detección de cubos por color mediante espacios de color HSV y
control visual automático del robot.

Pipeline de visión:
  1. Captura MJPEG desde rpicam-vid (640x480 @ 30fps)
  2. Suavizado Gaussiano (7x7) para reducción de ruido
  3. Conversión BGR → HSV
  4. Máscaras binarias por color con rangos HSV calibrados
  5. Morfología: apertura + cierre (kernel elíptico 9x9)
  6. Filtrado de contornos por área, relación ancho/alto y vértices
  7. Confirmación temporal en 4 frames (75% coincidencia)
  8. Control visual: error X → girar; centrado + dist≤30cm → ARM_PICK

Tópicos:
  Publica:  /taller3/objeto_detectado, /taller3/imagen_procesada,
            /cmd_vel, /taller3/comando_robot
  Suscribe: /taller3/ultrasonido
"""

import subprocess
import time
import threading
from collections import deque
import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Float32
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge

# ── Parámetros de cámara ──────────────────────────────────────
ANCHO_CAM  = 640
ALTO_CAM   = 480
FRAMERATE  = 30

# ── Parámetros de detección ───────────────────────────────────
AREA_MINIMA       = 2000
AREA_MAXIMA       = 200000
RELACION_MIN      = 0.4     # relación ancho/alto mínima
RELACION_MAX      = 2.0     # relación ancho/alto máxima
TOLERANCIA_CENTRO = 80      # píxeles de margen para "centrado"
FRAMES_CONFIRMAR  = 4       # frames consecutivos para confirmar
INTERVALO_CMD_SEG = 0.5     # intervalo mínimo entre comandos

# ── Distancia máxima para ejecutar ARM_PICK ───────────────────
DIST_PICK_CM = 30.0

# ── Rangos HSV calibrados (H, S, V) ──────────────────────────
RANGOS_HSV = {
    'Rojo': [
        (np.array([0,   100,  50]),  np.array([12,  255, 255])),
        (np.array([160, 100,  50]),  np.array([180, 255, 255])),
    ],
    'Verde': [(np.array([30, 60, 40]),  np.array([95,  255, 255]))],
    'Azul':  [(np.array([85, 60, 40]),  np.array([135, 255, 255]))],
}

# ── Colores BGR para visualización ───────────────────────────
COLOR_BGR = {
    'Rojo':  (0,   0,   220),
    'Verde': (0,   200,  30),
    'Azul':  (220,  50,   0),
}


class VisionNode(Node):
    def __init__(self):
        super().__init__('vision_node')

        # Publicadores
        self.pub_det = self.create_publisher(
            String, '/taller3/objeto_detectado', 10)
        self.pub_img = self.create_publisher(
            Image,  '/taller3/imagen_procesada', 10)
        self.pub_vel = self.create_publisher(
            Twist,  '/cmd_vel',                  10)
        self.pub_arm = self.create_publisher(
            String, '/taller3/comando_robot',     10)

        # Suscriptor de distancia ultrasónica
        self.sub_dist = self.create_subscription(
            Float32, '/taller3/ultrasonido', self._cb_dist, 10)

        self.bridge       = CvBridge()
        self.historial    = deque(maxlen=FRAMES_CONFIRMAR)
        self.ultimo_t     = 0.0
        self.distancia_cm = 999.0   # última distancia ultrasónica
        self.en_secuencia = False   # True mientras ARM_PICK está activo

        # Generador de frames MJPEG
        self.gen = leer_frames_mjpeg(ANCHO_CAM, ALTO_CAM, FRAMERATE)

        # Timer principal (1 frame por tick)
        self.timer = self.create_timer(1.0 / FRAMERATE, self._cb_frame)
        self.get_logger().info('VisionNode iniciado.')

    # ── Callback de distancia ultrasónica ─────────────────────
    def _cb_dist(self, msg: Float32):
        self.distancia_cm = msg.data

    # ── Callback principal (un frame por llamada) ─────────────
    def _cb_frame(self):
        if self.en_secuencia:
            return   # No procesar mientras el brazo está activo

        try:
            frame = next(self.gen)
        except StopIteration:
            self.get_logger().error('Cámara detuvo el stream.')
            return

        resultado, det = self._procesar(frame)

        # Publicar imagen procesada
        try:
            self.pub_img.publish(
                self.bridge.cv2_to_imgmsg(resultado, 'bgr8'))
        except Exception:
            pass

        # Publicar datos de detección y ejecutar lógica
        if det:
            msg      = String()
            msg.data = (
                f"color:{det['color']},"
                f"estado:{det['estado']},"
                f"cx:{det['centro'][0]},"
                f"cy:{det['centro'][1]},"
                f"dist:{self.distancia_cm:.1f}cm")
            self.pub_det.publish(msg)

            ahora = time.time()
            if (ahora - self.ultimo_t) > INTERVALO_CMD_SEG:
                self._logica(det)
                self.ultimo_t = ahora

    # ── Procesamiento de imagen ───────────────────────────────
    def _procesar(self, frame):
        """
        Aplica el pipeline de visión HSV y retorna el frame
        anotado y los datos de detección confirmada.
        """
        resultado   = frame.copy()
        alto, ancho = frame.shape[:2]
        cx_img      = ancho // 2

        # Líneas de referencia (centro de imagen)
        cv2.line(resultado, (cx_img, 0),      (cx_img, alto),    (180,180,180), 1)
        cv2.line(resultado, (0, alto//2),     (ancho, alto//2),  (180,180,180), 1)

        # Conversión a HSV con suavizado previo
        hsv   = cv2.cvtColor(
            cv2.GaussianBlur(frame, (7, 7), 0), cv2.COLOR_BGR2HSV)

        mejor      = None
        mejor_area = 0

        for nombre, rangos in RANGOS_HSV.items():
            # Crear máscara de color
            m = np.zeros(hsv.shape[:2], dtype=np.uint8)
            for (lo, hi) in rangos:
                m = cv2.bitwise_or(m, cv2.inRange(hsv, lo, hi))

            # Morfología para limpiar la máscara
            k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
            m = cv2.morphologyEx(m, cv2.MORPH_OPEN,  k, iterations=2)
            m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, k, iterations=2)

            # Encontrar contornos
            cnts, _ = cv2.findContours(
                m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            for cnt in cnts:
                area = cv2.contourArea(cnt)
                if not (AREA_MINIMA <= area <= AREA_MAXIMA):
                    continue

                x, y, w, h = cv2.boundingRect(cnt)
                if h == 0:
                    continue

                # Filtro por relación ancho/alto (forma cuadrada)
                if not (RELACION_MIN <= w / float(h) <= RELACION_MAX):
                    continue

                # Filtro por número de vértices (≥4 = cuadrado)
                p = cv2.arcLength(cnt, True)
                if len(cv2.approxPolyDP(cnt, 0.04 * p, True)) < 4:
                    continue

                # Calcular centro de masa
                M = cv2.moments(cnt)
                if M['m00'] == 0:
                    continue
                cx = int(M['m10'] / M['m00'])
                cy = int(M['m01'] / M['m00'])

                # Quedarse con el objeto de mayor área
                if area > mejor_area:
                    mejor_area = area
                    mejor = {
                        'color':  nombre,
                        'area':   area,
                        'centro': (cx, cy),
                        'bbox':   (x, y, w, h),
                        'cnt':    cnt
                    }

        det_conf = None

        if mejor:
            c_b        = COLOR_BGR.get(mejor['color'], (255, 255, 0))
            x, y, w, h = mejor['bbox']
            cx, cy     = mejor['centro']
            err_x      = cx - cx_img

            # Determinar estado de centrado
            if   abs(err_x) < TOLERANCIA_CENTRO: estado = 'CENTRADO'
            elif err_x < 0:                       estado = 'IZQUIERDA'
            else:                                 estado = 'DERECHA'

            # Dibujar anotaciones sobre el frame
            cv2.drawContours(resultado, [mejor['cnt']], -1, c_b, 2)
            cv2.rectangle(resultado, (x, y), (x+w, y+h), (255, 0, 0), 2)
            cv2.circle(resultado, (cx, cy), 6, (0, 255, 255), -1)
            cv2.putText(resultado,
                        f"{mejor['color']} | {estado}",
                        (x, max(y-10, 20)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, c_b, 2)
            cv2.putText(resultado,
                        f"Dist:{self.distancia_cm:.1f}cm  "
                        f"Area:{int(mejor['area'])}",
                        (x, max(y-32, 10)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, c_b, 1)
            cv2.putText(resultado, estado, (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                        (0,255,0) if estado == 'CENTRADO' else (0,165,255), 2)

            # Log en consola
            self.get_logger().info(
                f"[DETECCION] Color:{mejor['color']:<6} | "
                f"Area:{int(mejor['area']):>7} | "
                f"Centro:({cx},{cy}) | "
                f"ErrorX:{err_x:>+4} | "
                f"Estado:{estado:<10} | "
                f"Dist:{self.distancia_cm:.1f}cm")

            # Historial para confirmación temporal
            self.historial.append((mejor['color'], estado))

            if len(self.historial) == FRAMES_CONFIRMAR:
                cols = [h[0] for h in self.historial]
                ests = [h[1] for h in self.historial]
                c_d  = max(set(cols), key=cols.count)
                e_d  = max(set(ests), key=ests.count)
                if cols.count(c_d) >= FRAMES_CONFIRMAR - 1:
                    det_conf = {
                        'color':  c_d,
                        'estado': e_d,
                        'centro': (cx, cy)
                    }
                    cv2.putText(resultado,
                                f'CONFIRMADO:{c_d} '
                                f'Dist:{self.distancia_cm:.0f}cm',
                                (10, 60),
                                cv2.FONT_HERSHEY_SIMPLEX,
                                0.7, (0, 255, 100), 2)
        else:
            self.historial.clear()
            self.get_logger().info('[DETECCION] Sin objeto detectado')

        return resultado, det_conf

    # ── Lógica de navegación y agarre ─────────────────────────
    def _logica(self, det):
        """
        Control visual:
          - IZQUIERDA / DERECHA: gira para centrar el cubo
          - CENTRADO + dist<=30cm: ejecuta ARM_PICK automáticamente
          - CENTRADO + lejos: espera que el operador se acerque
        """
        estado = det['estado']
        color  = det['color']
        twist  = Twist()

        if estado == 'IZQUIERDA':
            twist.angular.z = 0.4
            self.pub_vel.publish(twist)
            self.get_logger().info(
                f'[LOGICA] {color} → Girando IZQUIERDA')

        elif estado == 'DERECHA':
            twist.angular.z = -0.4
            self.pub_vel.publish(twist)
            self.get_logger().info(
                f'[LOGICA] {color} → Girando DERECHA')

        elif estado == 'CENTRADO':
            # Para el robot
            self.pub_vel.publish(twist)

            if self.distancia_cm <= DIST_PICK_CM:
                self.get_logger().info(
                    f'[LOGICA] {color} CENTRADO y CERCA '
                    f'({self.distancia_cm:.1f}cm) → Ejecutando ARM_PICK')
                self._ejecutar_pick(color)
            else:
                self.get_logger().info(
                    f'[LOGICA] {color} CENTRADO pero LEJOS '
                    f'({self.distancia_cm:.1f}cm) — '
                    f'Acercar robot al cubo')

    # ── Ejecutar secuencia de agarre ──────────────────────────
    def _ejecutar_pick(self, color):
        """
        Publica ARM_PICK y bloquea el procesamiento de visión
        durante 8 segundos para que el brazo complete la secuencia.
        """
        self.en_secuencia = True
        self.historial.clear()

        cmd      = String()
        cmd.data = 'ARM_PICK'
        self.pub_arm.publish(cmd)
        self.get_logger().info(
            f'[ARM_PICK] Secuencia iniciada para cubo {color}')

        def _esperar():
            time.sleep(8.0)
            self.en_secuencia = False
            self.get_logger().info(
                '[ARM_PICK] Secuencia completada. Listo para siguiente cubo.')

        threading.Thread(target=_esperar, daemon=True).start()

    def destroy_node(self):
        twist = Twist()
        try:
            self.pub_vel.publish(twist)
        except Exception:
            pass
        super().destroy_node()


# ── Generador MJPEG desde rpicam-vid ─────────────────────────
def leer_frames_mjpeg(ancho, alto, fps):
    """
    Captura video de la cámara Raspberry Pi en formato MJPEG
    y lo decodifica frame a frame con OpenCV.
    """
    cmd = [
        'rpicam-vid', '-t', '0',
        '--width',     str(ancho),
        '--height',    str(alto),
        '--framerate', str(fps),
        '--codec',     'mjpeg',
        '--nopreview', '-o', '-'
    ]
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL, bufsize=0)
    buf = b''
    try:
        while True:
            chunk = proc.stdout.read(4096)
            if not chunk:
                break
            buf += chunk
            while True:
                ini = buf.find(b'\xff\xd8')
                fin = buf.find(b'\xff\xd9')
                if ini != -1 and fin != -1 and fin > ini:
                    jpg = buf[ini:fin+2]
                    buf = buf[fin+2:]
                    arr = np.frombuffer(jpg, dtype=np.uint8)
                    f   = cv2.imdecode(arr, cv2.IMREAD_COLOR)
                    if f is not None:
                        yield f
                else:
                    break
    finally:
        proc.terminate()
        proc.wait(timeout=2)


def main(args=None):
    rclpy.init(args=args)
    node = VisionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
