#!/usr/bin/env python3
"""
teleop_node.py — Taller 3, Grupo 2
Universidad de los Andes — IELE 3338 L — 2026-10

Control manual del robot diferencial por teclado.
Publica comandos Twist en /cmd_vel.

Controles:
  W / ↑   = Adelante
  S / ↓   = Atrás
  A / ←   = Giro izquierda
  D / →   = Giro derecha
  Q       = Aumentar velocidad
  E       = Disminuir velocidad
  Espacio = Parar
  Ctrl+C  = Salir
"""

import sys
import tty
import termios
import threading
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

# ── Velocidades por defecto ───────────────────────────────────
VEL_LINEAL_INIT = 0.20   # m/s
VEL_ANGULAR     = 0.40   # rad/s
VEL_PASO        = 0.05   # incremento/decremento de velocidad
VEL_MAX         = 0.50
VEL_MIN         = 0.05

BANNER = """
╔══════════════════════════════════════╗
║   TELEOP — Robot Diferencial         ║
║  W/↑: Adelante   S/↓: Atrás         ║
║  A/←: Giro Izq   D/→: Giro Der      ║
║  Q: +Velocidad   E: -Velocidad       ║
║  ESPACIO: Parar  Ctrl+C: Salir       ║
╚══════════════════════════════════════╝
"""


def get_key(settings):
    """Lee un carácter del teclado sin bloquear la terminal."""
    tty.setraw(sys.stdin.fileno())
    key = sys.stdin.read(1)
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key


class TeleopNode(Node):
    def __init__(self):
        super().__init__('teleop_node')
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.vel_lineal = VEL_LINEAL_INIT
        print(BANNER)
        print(f'Velocidad actual: {self.vel_lineal:.2f} m/s')

    def publicar(self, lx=0.0, az=0.0):
        msg = Twist()
        msg.linear.x  = lx
        msg.angular.z = az
        self.pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = TeleopNode()

    settings = termios.tcgetattr(sys.stdin)

    try:
        while rclpy.ok():
            key = get_key(settings)

            if key in ('w', 'W', '\x1b[A'):
                node.publicar(lx=node.vel_lineal)
                print(f'▲ ADELANTE  v={node.vel_lineal:.2f}')

            elif key in ('s', 'S', '\x1b[B'):
                node.publicar(lx=-node.vel_lineal)
                print(f'▼ ATRÁS     v={node.vel_lineal:.2f}')

            elif key in ('a', 'A', '\x1b[D'):
                node.publicar(az=VEL_ANGULAR)
                print('◄ IZQUIERDA')

            elif key in ('d', 'D', '\x1b[C'):
                node.publicar(az=-VEL_ANGULAR)
                print('► DERECHA')

            elif key == 'q':
                node.vel_lineal = min(node.vel_lineal + VEL_PASO, VEL_MAX)
                print(f'⬆ Velocidad: {node.vel_lineal:.2f} m/s')

            elif key == 'e':
                node.vel_lineal = max(node.vel_lineal - VEL_PASO, VEL_MIN)
                print(f'⬇ Velocidad: {node.vel_lineal:.2f} m/s')

            elif key == ' ':
                node.publicar()
                print('■ PARADO')

            elif key == '\x03':  # Ctrl+C
                break

    except Exception as e:
        print(f'Error: {e}')
    finally:
        node.publicar()  # Parar robot al salir
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
