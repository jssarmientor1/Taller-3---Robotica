#!/usr/bin/env python3
"""
web_dashboard_node.py — Taller 3, Grupo 2
Universidad de los Andes — IELE 3338 L — 2026-10

Dashboard web accesible desde cualquier PC en la misma red.
No requiere monitor conectado a la Raspberry Pi.

Acceso: http://IP_RASPBERRY:8081

Funcionalidades:
  - Video en vivo con bounding boxes (desde /taller3/imagen_procesada)
  - Odometría en tiempo real (x, y, theta)
  - Estado de detección de cubos (color, estado, distancia)
  - Control de motores (adelante, atrás, izquierda, derecha, stop)
  - Control del brazo (HOME, ARM_PICK, ARM_UP, ARM_DOWN, etc.)
  - Grabación y reproducción de recorridos
"""

import threading
import time
import socket
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse
import cv2

import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Float32MultiArray
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from taller3_interfaces.srv import PlayRoute

PUERTO = 8081

# Estado global compartido entre el nodo ROS2 y el servidor HTTP
estado = {
    'pose':      [0.0, 0.0, 0.0],
    'deteccion': 'Sin deteccion',
    'grabando':  False,
    'nombre_rec': '',
    'frame_jpg': None,
}
lock       = threading.Lock()
nodo_global = None


class WebDashboardNode(Node):
    def __init__(self):
        super().__init__('web_dashboard_node')

        self.sub_pose = self.create_subscription(
            Float32MultiArray, '/robot_pose',
            self._cb_pose, 10)
        self.sub_det = self.create_subscription(
            String, '/taller3/objeto_detectado',
            self._cb_det, 10)
        self.sub_img = self.create_subscription(
            Image, '/taller3/imagen_procesada',
            self._cb_img, 10)

        self.pub_ctrl = self.create_publisher(String, '/recording_ctrl',       10)
        self.pub_cmd  = self.create_publisher(String, '/taller3/comando_robot', 10)
        self.pub_vel  = self.create_publisher(
            __import__('geometry_msgs.msg', fromlist=['Twist']).Twist,
            '/cmd_vel', 10)

        self.cli_play = self.create_client(PlayRoute, '/play_route')
        self.bridge   = CvBridge()

        self.get_logger().info(
            f'WebDashboardNode iniciado — http://IP:{PUERTO}')

    def _cb_pose(self, msg):
        with lock:
            if len(msg.data) >= 3:
                estado['pose'] = list(msg.data[:3])

    def _cb_det(self, msg):
        with lock:
            estado['deteccion'] = msg.data

    def _cb_img(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            ret, jpg = cv2.imencode(
                '.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 75])
            if ret:
                with lock:
                    estado['frame_jpg'] = jpg.tobytes()
        except Exception:
            pass

    def iniciar_grabacion(self, nombre):
        msg = String(); msg.data = f'start:{nombre}'
        self.pub_ctrl.publish(msg)
        with lock:
            estado['grabando']    = True
            estado['nombre_rec']  = nombre

    def detener_grabacion(self):
        msg = String(); msg.data = 'stop'
        self.pub_ctrl.publish(msg)
        with lock:
            estado['grabando'] = False

    def enviar_cmd(self, cmd):
        msg = String(); msg.data = cmd
        self.pub_cmd.publish(msg)

    def reproducir(self, nombre):
        def _hilo():
            if not self.cli_play.wait_for_service(timeout_sec=2.0):
                return
            req = PlayRoute.Request(); req.filename = nombre
            future = self.cli_play.call_async(req)
            rclpy.spin_until_future_complete(self, future, timeout_sec=30.0)
        threading.Thread(target=_hilo, daemon=True).start()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # Silenciar logs HTTP

    def do_GET(self):
        parsed = urlparse(self.path)
        path   = parsed.path

        if   path == '/':              self._pagina_principal()
        elif path == '/stream':        self._stream_video()
        elif path == '/datos':         self._datos_json()
        elif path == '/cmd':
            params = parse_qs(parsed.query)
            cmd    = params.get('c', [''])[0]
            if cmd and nodo_global:
                nodo_global.enviar_cmd(cmd)
            self._ok()
        elif path == '/grabar':
            params = parse_qs(parsed.query)
            nombre = params.get('n', ['recorrido'])[0]
            if nodo_global:
                nodo_global.iniciar_grabacion(nombre)
            self._ok()
        elif path == '/parar_grabacion':
            if nodo_global:
                nodo_global.detener_grabacion()
            self._ok()
        elif path == '/reproducir':
            params = parse_qs(parsed.query)
            nombre = params.get('n', [''])[0]
            if nombre and nodo_global:
                nodo_global.reproducir(nombre)
            self._ok()
        else:
            self.send_response(404); self.end_headers()

    def _ok(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        self.end_headers()
        self.wfile.write(b'OK')

    def _datos_json(self):
        with lock:
            x, y, th = estado['pose']
            det       = estado['deteccion']
            grab      = estado['grabando']
            nombre    = estado['nombre_rec']
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        js = ('{"x":%.3f,"y":%.3f,"theta":%.3f,'
              '"deteccion":"%s","grabando":%s,"nombre":"%s"}'
              % (x, y, th, det,
                 'true' if grab else 'false', nombre))
        self.wfile.write(js.encode())

    def _stream_video(self):
        self.send_response(200)
        self.send_header('Content-type',
                         'multipart/x-mixed-replace; boundary=frame')
        self.end_headers()
        try:
            while True:
                with lock:
                    jpg = estado['frame_jpg']
                if jpg:
                    self.wfile.write(b'--frame\r\n')
                    self.wfile.write(b'Content-Type: image/jpeg\r\n\r\n')
                    self.wfile.write(jpg)
                    self.wfile.write(b'\r\n')
                time.sleep(0.033)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _pagina_principal(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.end_headers()
        html = open(__file__.replace('.py', '_html.html'),
                    encoding='utf-8').read() if False else _HTML_DASHBOARD
        self.wfile.write(html.encode('utf-8'))


# HTML del dashboard embebido en el código
_HTML_DASHBOARD = """<!DOCTYPE html>
<html><head><meta charset='utf-8'>
<title>Taller3 Grupo2 Dashboard</title>
<style>
body{margin:0;background:#0d0f14;color:#e2e8f8;font-family:monospace;}
.top{background:#13161d;padding:12px 20px;border-bottom:1px solid #252a38;
  display:flex;align-items:center;gap:16px;}
.top h1{color:#4f8ef7;font-size:18px;margin:0;}
.layout{display:flex;gap:0;height:calc(100vh - 50px);}
.panel{width:280px;background:#13161d;border-right:1px solid #252a38;
  padding:16px;overflow-y:auto;display:flex;flex-direction:column;gap:12px;}
.section{background:#1a1e28;border-radius:8px;padding:12px;}
.section h3{color:#f7c34f;font-size:12px;margin:0 0 8px 0;
  text-transform:uppercase;letter-spacing:1px;}
.val{color:#4fde8f;font-size:13px;margin:3px 0;}
.det{color:#b06ef7;font-size:12px;word-break:break-all;}
.btn{display:block;width:100%;padding:8px;margin:4px 0;
  border:1px solid #252a38;border-radius:6px;background:#252a38;
  color:#e2e8f8;cursor:pointer;font-family:monospace;font-size:12px;text-align:center;}
.btn:hover{background:#4f8ef7;color:#fff;border-color:#4f8ef7;}
.btn.green{border-color:#4fde8f;color:#4fde8f;}
.btn.green:hover{background:#4fde8f;color:#0d0f14;}
.btn.red{border-color:#f7614f;color:#f7614f;}
.btn.red:hover{background:#f7614f;color:#fff;}
.btn.yellow{border-color:#f7c34f;color:#f7c34f;}
.btn.yellow:hover{background:#f7c34f;color:#0d0f14;}
input{width:100%;padding:6px;background:#0d0f14;border:1px solid #252a38;
  border-radius:4px;color:#e2e8f8;font-family:monospace;font-size:12px;
  box-sizing:border-box;margin-bottom:4px;}
.stream{flex:1;display:flex;flex-direction:column;align-items:center;
  justify-content:center;background:#0a0c11;}
.stream img{max-width:100%;max-height:100%;border-radius:8px;}
.grab-on{color:#4fde8f;font-size:11px;}
.grab-off{color:#6b7694;font-size:11px;}
</style></head><body>
<div class='top'>
  <h1>Taller 3 Grupo 2 — Dashboard</h1>
  <span id='status' style='font-size:12px;color:#6b7694;'>Conectando...</span>
</div>
<div class='layout'>
  <div class='panel'>
    <div class='section'><h3>Odometria</h3>
      <div class='val' id='px'>X: 0.000 m</div>
      <div class='val' id='py'>Y: 0.000 m</div>
      <div class='val' id='pth'>Theta: 0.000 rad</div>
    </div>
    <div class='section'><h3>Deteccion Cubo</h3>
      <div class='det' id='det'>Sin deteccion</div>
    </div>
    <div class='section'><h3>Control Robot</h3>
      <button class='btn green'  onclick="cmd('FORWARD')">▲ ADELANTE</button>
      <button class='btn'        onclick="cmd('BACKWARD')">▼ ATRAS</button>
      <button class='btn'        onclick="cmd('LEFT')">◄ IZQUIERDA</button>
      <button class='btn'        onclick="cmd('RIGHT')">► DERECHA</button>
      <button class='btn red'    onclick="cmd('STOP')">■ STOP</button>
    </div>
    <div class='section'><h3>Control Brazo</h3>
      <button class='btn yellow' onclick="cmd('ARM_HOME')">HOME</button>
      <button class='btn yellow' onclick="cmd('ARM_PICK')">ARM PICK</button>
      <button class='btn yellow' onclick="cmd('AUTO_PICK')">AUTO PICK</button>
      <button class='btn'        onclick="cmd('ARM_DOWN')">Bajar</button>
      <button class='btn'        onclick="cmd('ARM_EXTEND')">Extender</button>
      <button class='btn'        onclick="cmd('ARM_UP')">Subir</button>
    </div>
    <div class='section'><h3>Grabacion</h3>
      <div id='grab_status' class='grab-off'>■ Inactivo</div>
      <input type='text' id='nombre_rec' placeholder='nombre_recorrido'/>
      <button class='btn green' onclick='iniciarGrab()'>▶ Iniciar</button>
      <button class='btn red'   onclick='pararGrab()'>■ Detener</button>
    </div>
    <div class='section'><h3>Reproducir</h3>
      <input type='text' id='nombre_play' placeholder='nombre_sin_extension'/>
      <button class='btn' onclick='reproducir()'>▶ Reproducir</button>
    </div>
  </div>
  <div class='stream'>
    <img src='/stream' id='video'/>
  </div>
</div>
<script>
function cmd(c){fetch('/cmd?c='+c);}
function iniciarGrab(){
  var n=document.getElementById('nombre_rec').value||'recorrido_1';
  fetch('/grabar?n='+encodeURIComponent(n));}
function pararGrab(){fetch('/parar_grabacion');}
function reproducir(){
  var n=document.getElementById('nombre_play').value;
  if(n) fetch('/reproducir?n='+encodeURIComponent(n));}
function actualizar(){
  fetch('/datos').then(r=>r.json()).then(d=>{
    document.getElementById('px').textContent='X: '+d.x.toFixed(3)+' m';
    document.getElementById('py').textContent='Y: '+d.y.toFixed(3)+' m';
    document.getElementById('pth').textContent='Theta: '+d.theta.toFixed(3)+' rad';
    document.getElementById('det').textContent=d.deteccion;
    var gs=document.getElementById('grab_status');
    if(d.grabando){gs.textContent='● Grabando: '+d.nombre;gs.className='grab-on';}
    else{gs.textContent='■ Inactivo';gs.className='grab-off';}
    document.getElementById('status').textContent='Conectado';
  }).catch(()=>{document.getElementById('status').textContent='Sin conexion';});}
setInterval(actualizar,500);actualizar();
</script></body></html>"""


def iniciar_servidor():
    srv = HTTPServer(('0.0.0.0', PUERTO), Handler)
    print(f'[WEB] Dashboard activo en puerto {PUERTO}')
    srv.serve_forever()


def main(args=None):
    global nodo_global

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
    except Exception:
        ip = 'IP_RASPBERRY'

    print('=' * 55)
    print(f'  Abre en tu PC: http://{ip}:{PUERTO}')
    print('=' * 55)

    rclpy.init(args=args)
    nodo_global = WebDashboardNode()

    hilo = threading.Thread(target=iniciar_servidor, daemon=True)
    hilo.start()

    try:
        rclpy.spin(nodo_global)
    except KeyboardInterrupt:
        pass
    finally:
        nodo_global.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
