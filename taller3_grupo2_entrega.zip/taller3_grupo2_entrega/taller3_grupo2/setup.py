from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'taller3_grupo2'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Grupo 2',
    maintainer_email='grupo2@uniandes.edu.co',
    description='Taller 3 - Robot Diferencial con Brazo y Vision',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'teleop_node        = taller3_grupo2.teleop_node:main',
            'encoder_node       = taller3_grupo2.encoder_node:main',
            'odometry_node      = taller3_grupo2.odometry_node:main',
            'serial_bridge_node = taller3_grupo2.serial_bridge_node:main',
            'recorder_node      = taller3_grupo2.recorder_node:main',
            'player_node        = taller3_grupo2.player_node:main',
            'vision_node        = taller3_grupo2.vision_node:main',
            'web_dashboard_node = taller3_grupo2.web_dashboard_node:main',
        ],
    },
)
