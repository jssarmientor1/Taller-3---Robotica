"""
robot_launch.py — Taller 3, Grupo 2
Universidad de los Andes — IELE 3338 L — 2026-10

Lanza todos los nodos del sistema robótico en un solo comando.

Uso:
  ros2 launch taller3_grupo2 robot_launch.py
"""

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='taller3_grupo2',
            executable='encoder_node',
            name='encoder_node',
            output='screen',
        ),
        Node(
            package='taller3_grupo2',
            executable='odometry_node',
            name='odometry_node',
            output='screen',
        ),
        Node(
            package='taller3_grupo2',
            executable='serial_bridge_node',
            name='serial_bridge_node',
            output='screen',
        ),
        Node(
            package='taller3_grupo2',
            executable='recorder_node',
            name='recorder_node',
            output='screen',
        ),
        Node(
            package='taller3_grupo2',
            executable='player_node',
            name='player_node',
            output='screen',
        ),
        Node(
            package='taller3_grupo2',
            executable='vision_node',
            name='vision_node',
            output='screen',
        ),
        Node(
            package='taller3_grupo2',
            executable='web_dashboard_node',
            name='web_dashboard_node',
            output='screen',
        ),
    ])
